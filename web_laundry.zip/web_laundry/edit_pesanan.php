<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$user = $_SESSION['user'];
if (!isset($_GET['id'])) {
    header('Location: riwayat_pesanan.php');
    exit();
}
$id = $_GET['id'];

$stmt = $pdo->prepare('SELECT * FROM pesanan WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $user['id']]);
$pesanan = $stmt->fetch();
if (!$pesanan || $pesanan['status'] !== 'pending') {
    header('Location: riwayat_pesanan.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jenis_layanan = $_POST['jenis_layanan'];
    $berat = floatval($_POST['berat']);
    $jadwal_jemput = $_POST['jadwal_jemput'];
    $catatan = trim($_POST['catatan'] ?? '');

    $harga_per_kg = [
        'cuci_kering' => 8000,
        'cuci_setrika' => 12000,
        'setrika_saja' => 6000,
        'dry_clean' => 15000,
        'premium' => 20000
    ];
    $total_harga = $harga_per_kg[$jenis_layanan] * $berat;

    $stmt = $pdo->prepare('UPDATE pesanan SET jenis_layanan=?, berat=?, total_harga=?, jadwal_jemput=?, catatan=? WHERE id=? AND user_id=?');
    $stmt->execute([$jenis_layanan, $berat, $total_harga, $jadwal_jemput, $catatan, $id, $user['id']]);
    $_SESSION['success'] = 'Pesanan berhasil diupdate!';
    header('Location: riwayat_pesanan.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pesanan - FreshLaundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-tshirt me-2"></i>FreshLaundry
            </a>
        </div>
    </nav>
    <section class="py-5" style="margin-top: 80px;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="card border-0 shadow">
                        <div class="card-header bg-primary text-white text-center py-3">
                            <h3 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Pesanan</h3>
                        </div>
                        <div class="card-body p-4">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Jenis Layanan</label>
                                    <select name="jenis_layanan" class="form-select" required>
                                        <option value="cuci_kering" <?= $pesanan['jenis_layanan']==='cuci_kering'?'selected':'' ?>>Cuci Kering</option>
                                        <option value="cuci_setrika" <?= $pesanan['jenis_layanan']==='cuci_setrika'?'selected':'' ?>>Cuci + Setrika</option>
                                        <option value="setrika_saja" <?= $pesanan['jenis_layanan']==='setrika_saja'?'selected':'' ?>>Setrika Saja</option>
                                        <option value="dry_clean" <?= $pesanan['jenis_layanan']==='dry_clean'?'selected':'' ?>>Dry Clean</option>
                                        <option value="premium" <?= $pesanan['jenis_layanan']==='premium'?'selected':'' ?>>Premium Care</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Berat (kg)</label>
                                    <input type="number" name="berat" class="form-control" min="1" step="0.5" value="<?= $pesanan['berat'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jadwal Penjemputan</label>
                                    <input type="datetime-local" name="jadwal_jemput" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime($pesanan['jadwal_jemput'])) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Catatan</label>
                                    <textarea name="catatan" class="form-control" rows="2"><?= htmlspecialchars($pesanan['catatan']) ?></textarea>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                    <a href="riwayat_pesanan.php" class="btn btn-secondary">Batal</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html> 