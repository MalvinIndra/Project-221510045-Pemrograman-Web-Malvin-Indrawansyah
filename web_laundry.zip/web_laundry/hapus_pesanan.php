<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$user = $_SESSION['user'];
if (!isset($_GET['id'])) {
    header('Location: riwayat_pesanan.php');
    exit();
}
$id = $_GET['id'];

$stmt = $pdo->prepare('SELECT * FROM pesanan WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $user['id']]);
$pesanan = $stmt->fetch();
if (!$pesanan || $pesanan['status'] !== 'pending') {
    header('Location: riwayat_pesanan.php');
    exit();
}

$stmt = $pdo->prepare('DELETE FROM pesanan WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $user['id']]);
$_SESSION['success'] = 'Pesanan berhasil dihapus!';
header('Location: riwayat_pesanan.php');
exit(); 